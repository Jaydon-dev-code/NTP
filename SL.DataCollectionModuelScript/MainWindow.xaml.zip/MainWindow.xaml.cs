﻿using System.Windows;
using OpenQA.Selenium;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;

namespace SL.DataCollectionModuelScropt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            var options = new EdgeOptions();
            // options.AddArguments("--headless=new"); // 无头模式（可选）
            using IWebDriver driver = new EdgeDriver(options);
            driver.Url = "http://192.168.1.178";
            //driver.Url =
            //    "file:///C:/Users/C2300040802/Desktop/新建文件夹 (4)/新建文本文档 (3).html";
            driver.FindElement(By.Id("txtAct")).SendKeys("admin");
            driver.FindElement(By.Id("txtPwd")).SendKeys("admin");
            var form = driver.FindElement(By.Id("frmSetting"));
            form.Submit();

            var linkBu = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            driver.SwitchTo().Frame("main");
     
          var link=   driver.FindElement(By.LinkText("以太网接口参数"));
            link.Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));



            // IP段
            driver.FindElement(By.Name("IP1")).Clear();
            driver.FindElement(By.Name("IP1")).SendKeys("192");

            driver.FindElement(By.Name("IP2")).Clear();
            driver.FindElement(By.Name("IP2")).SendKeys("168");

            driver.FindElement(By.Name("IP3")).Clear();
            driver.FindElement(By.Name("IP3")).SendKeys("1");

            driver.FindElement(By.Name("IP4")).Clear();
            driver.FindElement(By.Name("IP4")).SendKeys("203");
            //mac
            driver.FindElement(By.Name("MK1")).Clear();
            driver.FindElement(By.Name("MK1")).SendKeys("255");

            driver.FindElement(By.Name("MK2")).Clear();
            driver.FindElement(By.Name("MK2")).SendKeys("255");

            driver.FindElement(By.Name("MK3")).Clear();
            driver.FindElement(By.Name("MK3")).SendKeys("0");

            driver.FindElement(By.Name("MK4")).Clear();
            driver.FindElement(By.Name("MK4")).SendKeys("0");

            driver.FindElement(By.Name("GW1")).Clear();
            driver.FindElement(By.Name("GW1")).SendKeys("192");
            //gw
            driver.FindElement(By.Name("GW2")).Clear();
            driver.FindElement(By.Name("GW2")).SendKeys("168");

            driver.FindElement(By.Name("GW3")).Clear();
            driver.FindElement(By.Name("GW3")).SendKeys("1");

            driver.FindElement(By.Name("GW4")).Clear();
            driver.FindElement(By.Name("GW4")).SendKeys("1");

            driver.FindElement(By.Name("config")).Submit();
            driver.Quit();
        
            using IWebDriver chekcDriver = new EdgeDriver(options);
            chekcDriver.Url = "http://192.168.1.203";
            var checkConfig = new WebDriverWait(chekcDriver, TimeSpan.FromSeconds(10));
            checkConfig.Until(d => d.FindElement(By.Id("txtAct")));
            chekcDriver.FindElement(By.Id("txtAct")).SendKeys("admin");
            chekcDriver.FindElement(By.Id("txtPwd")).SendKeys("admin");
            var checkForm = chekcDriver.FindElement(By.Id("frmSetting"));
            checkForm.Submit();
            var checkBu = new WebDriverWait(chekcDriver, TimeSpan.FromSeconds(10));
            chekcDriver.SwitchTo().Frame("main");
            var checkLink = chekcDriver.FindElement(By.LinkText("以太网接口参数"));
            checkLink.Click();
 
            WebDriverWait wait1 = new WebDriverWait(chekcDriver, TimeSpan.FromSeconds(10));

            // IP段
          var ip1=  chekcDriver.FindElement(By.Name("IP1")).GetAttribute("value");
            var ip2=  chekcDriver.FindElement(By.Name("IP2")).GetAttribute("value");
            var ip3=  chekcDriver.FindElement(By.Name("IP3")).GetAttribute("value");
            var ip4=  chekcDriver.FindElement(By.Name("IP4")).GetAttribute("value");



        }
    }
}
